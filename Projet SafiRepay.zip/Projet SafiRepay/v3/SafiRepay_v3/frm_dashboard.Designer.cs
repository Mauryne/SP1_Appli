﻿namespace SafiRepay
{
    partial class frm_dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_window = new System.Windows.Forms.Panel();
            this.lbl_dashboard = new System.Windows.Forms.Label();
            this.btn_deconnection = new System.Windows.Forms.Button();
            this.btn_expenseSheets = new FontAwesome.Sharp.IconButton();
            this.pnl_menu = new System.Windows.Forms.Panel();
            this.btn_rulesManagement = new FontAwesome.Sharp.IconButton();
            this.pnl_menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_window
            // 
            this.pnl_window.AutoScroll = true;
            this.pnl_window.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pnl_window.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_window.Location = new System.Drawing.Point(207, 0);
            this.pnl_window.Name = "pnl_window";
            this.pnl_window.Size = new System.Drawing.Size(1043, 675);
            this.pnl_window.TabIndex = 1;
            this.pnl_window.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_window_Paint);
            // 
            // lbl_dashboard
            // 
            this.lbl_dashboard.AutoSize = true;
            this.lbl_dashboard.Font = new System.Drawing.Font("Nachlieli CLM", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_dashboard.Location = new System.Drawing.Point(0, 9);
            this.lbl_dashboard.Name = "lbl_dashboard";
            this.lbl_dashboard.Size = new System.Drawing.Size(203, 30);
            this.lbl_dashboard.TabIndex = 0;
            this.lbl_dashboard.Text = "Tableau de bord";
            // 
            // btn_deconnection
            // 
            this.btn_deconnection.FlatAppearance.BorderSize = 0;
            this.btn_deconnection.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_deconnection.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_deconnection.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_deconnection.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_deconnection.Location = new System.Drawing.Point(0, 510);
            this.btn_deconnection.Name = "btn_deconnection";
            this.btn_deconnection.Size = new System.Drawing.Size(204, 23);
            this.btn_deconnection.TabIndex = 3;
            this.btn_deconnection.Text = "Se déconnecter";
            this.btn_deconnection.UseVisualStyleBackColor = true;
            this.btn_deconnection.Click += new System.EventHandler(this.btn_deconnection_Click);
            // 
            // btn_expenseSheets
            // 
            this.btn_expenseSheets.FlatAppearance.BorderSize = 0;
            this.btn_expenseSheets.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_expenseSheets.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_expenseSheets.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_expenseSheets.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_expenseSheets.IconChar = FontAwesome.Sharp.IconChar.FileAlt;
            this.btn_expenseSheets.IconColor = System.Drawing.Color.Black;
            this.btn_expenseSheets.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_expenseSheets.IconSize = 25;
            this.btn_expenseSheets.Location = new System.Drawing.Point(0, 76);
            this.btn_expenseSheets.Name = "btn_expenseSheets";
            this.btn_expenseSheets.Size = new System.Drawing.Size(204, 47);
            this.btn_expenseSheets.TabIndex = 5;
            this.btn_expenseSheets.Text = "Gestion des fiches de frais";
            this.btn_expenseSheets.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_expenseSheets.UseVisualStyleBackColor = true;
            this.btn_expenseSheets.Click += new System.EventHandler(this.btn_expenseSheets_Click);
            // 
            // pnl_menu
            // 
            this.pnl_menu.AutoScroll = true;
            this.pnl_menu.AutoSize = true;
            this.pnl_menu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnl_menu.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pnl_menu.Controls.Add(this.btn_rulesManagement);
            this.pnl_menu.Controls.Add(this.btn_expenseSheets);
            this.pnl_menu.Controls.Add(this.btn_deconnection);
            this.pnl_menu.Controls.Add(this.lbl_dashboard);
            this.pnl_menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnl_menu.Location = new System.Drawing.Point(0, 0);
            this.pnl_menu.Name = "pnl_menu";
            this.pnl_menu.Size = new System.Drawing.Size(207, 675);
            this.pnl_menu.TabIndex = 0;
            this.pnl_menu.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_menu_Paint);
            // 
            // btn_rulesManagement
            // 
            this.btn_rulesManagement.FlatAppearance.BorderSize = 0;
            this.btn_rulesManagement.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_rulesManagement.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_rulesManagement.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_rulesManagement.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_rulesManagement.IconChar = FontAwesome.Sharp.IconChar.PencilRuler;
            this.btn_rulesManagement.IconColor = System.Drawing.Color.Black;
            this.btn_rulesManagement.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_rulesManagement.IconSize = 25;
            this.btn_rulesManagement.Location = new System.Drawing.Point(0, 129);
            this.btn_rulesManagement.Name = "btn_rulesManagement";
            this.btn_rulesManagement.Size = new System.Drawing.Size(204, 47);
            this.btn_rulesManagement.TabIndex = 6;
            this.btn_rulesManagement.Text = "Gestion des règles";
            this.btn_rulesManagement.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_rulesManagement.UseVisualStyleBackColor = true;
            this.btn_rulesManagement.Click += new System.EventHandler(this.btn_rulesManagement_Click);
            // 
            // frm_dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1250, 675);
            this.Controls.Add(this.pnl_window);
            this.Controls.Add(this.pnl_menu);
            this.Name = "frm_dashboard";
            this.Text = "Tableau de bord";
            this.Load += new System.EventHandler(this.frm_dashboard_Load);
            this.pnl_menu.ResumeLayout(false);
            this.pnl_menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel pnl_window;
        private System.Windows.Forms.Label lbl_dashboard;
        private System.Windows.Forms.Button btn_deconnection;
        private FontAwesome.Sharp.IconButton btn_expenseSheets;
        private System.Windows.Forms.Panel pnl_menu;
        private FontAwesome.Sharp.IconButton btn_rulesManagement;
    }
}
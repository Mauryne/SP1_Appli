﻿using SafiRepay.RAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay.Pages
{
    public partial class frm_ruleUpdate : Form
    {
        public Boolean isClosedUpdate = false;
        public string name;
        public string amount;
        public string id;

        public frm_ruleUpdate(string aName, string anAmount, string anId)
        {
            this.amount = anAmount;
            var amountLength = anAmount.Length;
            var amountOriginal = this.amount.Substring(0, amountLength - 2);

            NumberFormatInfo nfi = CultureInfo.CreateSpecificCulture(CultureInfo.CurrentCulture.Name).NumberFormat;
            nfi.NumberDecimalSeparator = ".";
            decimal decimalAmount = Convert.ToDecimal(amountOriginal);
            string realAmount = decimalAmount.ToString("0.00", nfi);

            this.name = aName;
            this.id = anId;
            InitializeComponent();
            tbx_name.Text = this.name;
            tbx_amount.Text = realAmount;
        }

        public static bool IsAllLetters(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsLetter(c))
                    return false;
            }
            return true;
        }

        public static bool IsAllDigits(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c))
                    return false;
            }
            return true;
        }

        private void btn_validate_Click(object sender, EventArgs e)
        {
            if (tbx_name.Text == null || tbx_name.Text == "" || tbx_amount.Text == null || tbx_amount.Text == "" || IsAllDigits(tbx_name.Text) == true || IsAllLetters(tbx_amount.Text) == true)
            {
                MessageBox.Show("Veuillez entrer des données correctes");
            }
            else
            {
                ExpensePackagesRAO.updateOne(this.id, tbx_name.Text, tbx_amount.Text);
                this.Close();
                isClosedUpdate = true;
            }
        }

        private void frm_ruleUpdate_Load(object sender, EventArgs e)
        {

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            isClosedUpdate = true;
        }

        private void tbx_description_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void frm_ruleUpdate_Load_1(object sender, EventArgs e)
        {

        }

        private void tbx_amount_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}

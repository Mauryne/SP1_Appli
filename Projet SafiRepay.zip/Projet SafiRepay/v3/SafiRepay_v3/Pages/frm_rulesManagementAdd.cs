﻿using SafiRepay.RAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay.Pages
{
    public partial class frm_rulesManagementAdd : Form
    {
        public Boolean isClosedAdd = false;

        public frm_rulesManagementAdd()
        {
            InitializeComponent();
        }

        private void btn_echap_Click(object sender, EventArgs e)
        {
            isClosedAdd = true;
            this.Close();
        }

        private void frm_rulesManagementAdd_Load(object sender, EventArgs e)
        {

        }

        public static bool IsAllLetters(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsLetter(c))
                    return false;
            }
            return true;
        }

        public static bool IsAllDigits(string s)
        {
            foreach (char c in s)
            {
                if (!Char.IsDigit(c))
                    return false;
            }
            return true;
        }
        
        private void btn_validate_Click(object sender, EventArgs e)
        {
            if (tbx_ruleName.Text == null || tbx_ruleName.Text == "" || tbx_ruleAmount.Text == null || tbx_ruleAmount.Text == "" || IsAllDigits(tbx_ruleName.Text) == true || IsAllLetters(tbx_ruleAmount.Text) == true)
            {
                MessageBox.Show("Veuillez entrer des données correctes");
            }
            else
            {
                ExpensePackagesRAO.create(tbx_ruleName.Text, tbx_ruleAmount.Text);
                isClosedAdd = true;
                this.Close();
            }
        }
    }
}

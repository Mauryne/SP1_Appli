﻿using SafiRepay.RAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay.Pages
{
    public partial class frm_rulesManagementAdd : Form
    {
        public Boolean isClosedAdd = false;

        public frm_rulesManagementAdd()
        {
            InitializeComponent();
        }

        private void btn_echap_Click(object sender, EventArgs e)
        {
            isClosedAdd = true;
            this.Close();
        }

        private void frm_rulesManagementAdd_Load(object sender, EventArgs e)
        {

        }

        private void btn_validate_Click(object sender, EventArgs e)
        {
            decimal number = 0;
            var amount = tbx_ruleAmount.Text;
            var canConvertAmount = decimal.TryParse(amount, out number);

            if (tbx_ruleName.Text == null || tbx_ruleName.Text == "" || tbx_ruleAmount.Text == null || tbx_ruleAmount.Text == "" || canConvertAmount != true)
            {
                MessageBox.Show("Veuillez entrer des données correctes");
            }
            else
            {
                ExpensePackagesRAO.create(tbx_ruleName.Text, tbx_ruleAmount.Text);
                isClosedAdd = true;
                this.Close();
            }
        }
    }
}

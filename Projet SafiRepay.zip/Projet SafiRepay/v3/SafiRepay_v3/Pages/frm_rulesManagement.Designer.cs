﻿namespace SafiRepay
{
    partial class frm_rulesManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl_rulesManagement = new System.Windows.Forms.Label();
            this.btn_simulation = new System.Windows.Forms.Button();
            this.dgv_rulesManagement = new System.Windows.Forms.DataGridView();
            this.Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RuleManagementDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RuleManagementUpdate = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_add = new FontAwesome.Sharp.IconButton();
            this.btn_refresh = new System.Windows.Forms.Button();
            this.rAOBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_rulesManagement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rAOBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_rulesManagement
            // 
            this.lbl_rulesManagement.AutoSize = true;
            this.lbl_rulesManagement.Font = new System.Drawing.Font("Nachlieli CLM", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_rulesManagement.Location = new System.Drawing.Point(13, 9);
            this.lbl_rulesManagement.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_rulesManagement.Name = "lbl_rulesManagement";
            this.lbl_rulesManagement.Size = new System.Drawing.Size(237, 30);
            this.lbl_rulesManagement.TabIndex = 5;
            this.lbl_rulesManagement.Text = "Gestion des règles";
            // 
            // btn_simulation
            // 
            this.btn_simulation.FlatAppearance.BorderSize = 0;
            this.btn_simulation.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_simulation.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_simulation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_simulation.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_simulation.Location = new System.Drawing.Point(643, 42);
            this.btn_simulation.Margin = new System.Windows.Forms.Padding(4);
            this.btn_simulation.Name = "btn_simulation";
            this.btn_simulation.Size = new System.Drawing.Size(112, 28);
            this.btn_simulation.TabIndex = 30;
            this.btn_simulation.Text = "Simulation";
            this.btn_simulation.UseVisualStyleBackColor = true;
            this.btn_simulation.Click += new System.EventHandler(this.btn_simulation_Click);
            // 
            // dgv_rulesManagement
            // 
            this.dgv_rulesManagement.AllowUserToAddRows = false;
            this.dgv_rulesManagement.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_rulesManagement.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Id,
            this.RuleManagementDescription,
            this.Amount,
            this.RuleManagementUpdate});
            this.dgv_rulesManagement.Location = new System.Drawing.Point(261, 157);
            this.dgv_rulesManagement.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_rulesManagement.Name = "dgv_rulesManagement";
            this.dgv_rulesManagement.Size = new System.Drawing.Size(344, 375);
            this.dgv_rulesManagement.TabIndex = 31;
            this.dgv_rulesManagement.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_rulesManagement_CellContentClick);
            // 
            // Id
            // 
            this.Id.HeaderText = "Id";
            this.Id.Name = "Id";
            this.Id.Visible = false;
            // 
            // RuleManagementDescription
            // 
            this.RuleManagementDescription.HeaderText = "Nom";
            this.RuleManagementDescription.Name = "RuleManagementDescription";
            this.RuleManagementDescription.ReadOnly = true;
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Montant";
            this.Amount.Name = "Amount";
            // 
            // RuleManagementUpdate
            // 
            this.RuleManagementUpdate.HeaderText = "Modifier";
            this.RuleManagementUpdate.Name = "RuleManagementUpdate";
            this.RuleManagementUpdate.ReadOnly = true;
            this.RuleManagementUpdate.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.RuleManagementUpdate.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // btn_add
            // 
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_add.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_add.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.btn_add.IconColor = System.Drawing.Color.Black;
            this.btn_add.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btn_add.IconSize = 25;
            this.btn_add.Location = new System.Drawing.Point(702, 113);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(41, 40);
            this.btn_add.TabIndex = 44;
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btn_refresh
            // 
            this.btn_refresh.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_refresh.FlatAppearance.BorderSize = 0;
            this.btn_refresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_refresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_refresh.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refresh.Location = new System.Drawing.Point(261, 130);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 23);
            this.btn_refresh.TabIndex = 45;
            this.btn_refresh.Text = "Rafraîchir";
            this.btn_refresh.UseVisualStyleBackColor = false;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // rAOBindingSource
            // 
            this.rAOBindingSource.DataSource = typeof(SafiRepay.RAO.RAO);
            this.rAOBindingSource.CurrentChanged += new System.EventHandler(this.rAOBindingSource_CurrentChanged);
            // 
            // frm_rulesManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1043, 675);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.dgv_rulesManagement);
            this.Controls.Add(this.btn_simulation);
            this.Controls.Add(this.lbl_rulesManagement);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_rulesManagement";
            this.Text = "Gestion des règles";
            this.Load += new System.EventHandler(this.frm_rulesManagement_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_rulesManagement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rAOBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_rulesManagement;
        private System.Windows.Forms.Button btn_simulation;
        private System.Windows.Forms.DataGridView dgv_rulesManagement;
        private FontAwesome.Sharp.IconButton btn_add;
        private System.Windows.Forms.BindingSource rAOBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn RuleManagementDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewButtonColumn RuleManagementUpdate;
        private System.Windows.Forms.Button btn_refresh;
    }
}
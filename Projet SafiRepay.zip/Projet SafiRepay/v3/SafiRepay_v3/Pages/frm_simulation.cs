﻿using SafiRepay.Pages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace SafiRepay
{
    public partial class frm_simulation : Form
    {
        public Boolean isClosedSimulation = false;
        public frm_simulation()
        {
            InitializeComponent();
            isClosedSimulation = true;
        }

        private void btn_echap_Click(object sender, EventArgs e)
        {
            isClosedSimulation = true;
            this.Close();
        }

        private void cht_rulesManagement_Click(object sender, EventArgs e)
        {

        }

        public void BarExpenseSheets()
        {
            this.cht_rulesManagement.Series.Clear();

            // Data arrays
            string[] seriesArray = { "Fiches validées" , "Fiches non validées", "Fiches en attente de validation", "Fiches en attente de preuves", "Fiches refusées pour manque de preuve", "Fiches refusées pour montant trop élevé" };
            int[] pointsArray = { 40, 10, 15, 15, 10, 10 };

            // Set palette
            this.cht_rulesManagement.Palette = ChartColorPalette.Chocolate;

            // Set title
            var date = Properties.Settings.Default.p_month;
            date += "/" + Properties.Settings.Default.p_year;
            this.cht_rulesManagement.Titles.Add("Etat des fiches de frais - Période : " + date);

            // Add series.
            for (int i = 0; i < seriesArray.Length; i++)
            {
                Series series = this.cht_rulesManagement.Series.Add(seriesArray[i]);
                series.Points.Add(pointsArray[i]);
            }
        }

        private void frm_simulation_Load(object sender, EventArgs e)
        {
            BarExpenseSheets(); //Show bar chart
        }

        private void btn_dateChoice_Click(object sender, EventArgs e)
        {
            frm_simulationPeriod newWin = new frm_simulationPeriod();
            newWin.Show();
        }

        private void btn_updateRules_Click(object sender, EventArgs e)
        {
            frm_simulationPeriod newWin = new frm_simulationPeriod();
            newWin.Show();
        }

        private void btn_validate_Click(object sender, EventArgs e)
        {
            isClosedSimulation = true;
            this.Close();
        }

        private void btn_updateRules_Click_1(object sender, EventArgs e)
        {

        }

        private void lbl_rulesSimulation_Click(object sender, EventArgs e)
        {

        }
    }
}

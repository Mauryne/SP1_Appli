﻿using SafiRepay.RAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay.Pages
{
    public partial class frm_expenseUpdate : Form
    {
        public Boolean isClosedUpdate = false;
        public string state;
        public string amount;
        public string quantity;
        public string proof;
        public string id;
        public frm_expenseUpdate(string anId, string aState, string anAmount, string aQuantity, string aProof)
        {
            this.id = anId;
            this.state = aState;
            this.amount = anAmount;
            var amountLength = anAmount.Length;
            var amountOriginal = this.amount.Substring(0, amountLength - 2);

            NumberFormatInfo nfi = CultureInfo.CreateSpecificCulture(CultureInfo.CurrentCulture.Name).NumberFormat;
            nfi.NumberDecimalSeparator = ".";
            decimal decimalAmount = Convert.ToDecimal(amountOriginal);
            string realAmount = decimalAmount.ToString("0.00", nfi);

            this.quantity = aQuantity;
            this.proof = aProof;
            InitializeComponent();
            lbx_state.SelectedItem = this.state;
            tbx_amount.Text = realAmount;
            tbx_quantity.Text = quantity;
            if (proof == "Non")
            {
                rbtn_no.Checked = true;
                rbtn_yes.Checked = false;
            } else
            {
                rbtn_no.Checked = false;
                rbtn_yes.Checked = true;
            }
        }

        private void frm_expenseUpdate_Load(object sender, EventArgs e)
        {
            lbl_proof.Hide();
            rbtn_no.Hide();
            rbtn_yes.Hide();
        }

        private void btn_validate_Click(object sender, EventArgs e)
        {
            int expense_state_id = 0;
            if (lbx_state.SelectedItem.ToString() == "En attente de validation")
            {
                expense_state_id = 1;
            }
            else if (lbx_state.SelectedItem.ToString() == "En attente de preuve")
            {
                expense_state_id = 2;
            }
            else if (lbx_state.SelectedItem.ToString() == "Validé")
            {
                expense_state_id = 3;
            }
            else if (lbx_state.SelectedItem.ToString() == "Refusé pour manque de preuve")
            {
                expense_state_id = 4;
            }
            else if (lbx_state.SelectedItem.ToString() == "Refusé pour montant trop élevé")
            {
                expense_state_id = 5;
            }

            ExpensesRAO.updateOne(id, Convert.ToInt32(tbx_quantity.Text), tbx_amount.Text, expense_state_id);

            this.Close();
            isClosedUpdate = true;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            this.Close();
            isClosedUpdate = true;
        }

        private void tbx_amount_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_proof_Click(object sender, EventArgs e)
        {

        }

        private void rbtn_yes_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

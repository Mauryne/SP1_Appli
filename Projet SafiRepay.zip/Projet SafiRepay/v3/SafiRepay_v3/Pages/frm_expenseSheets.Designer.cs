﻿namespace SafiRepay
{
    partial class frm_expenseSheets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_expenseSheets = new System.Windows.Forms.Label();
            this.dgv_expenses = new System.Windows.Forms.DataGridView();
            this.dgv_expenseSheet = new System.Windows.Forms.DataGridView();
            this.IdExpenseSheet = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Choose = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_show = new System.Windows.Forms.Button();
            this.IdExpense = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ExpenseType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CreationDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Proof = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Update = new System.Windows.Forms.DataGridViewButtonColumn();
            this.btn_refresh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_expenses)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_expenseSheet)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_expenseSheets
            // 
            this.lbl_expenseSheets.AutoSize = true;
            this.lbl_expenseSheets.Font = new System.Drawing.Font("Nachlieli CLM", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_expenseSheets.Location = new System.Drawing.Point(-1, 9);
            this.lbl_expenseSheets.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_expenseSheets.Name = "lbl_expenseSheets";
            this.lbl_expenseSheets.Size = new System.Drawing.Size(280, 30);
            this.lbl_expenseSheets.TabIndex = 4;
            this.lbl_expenseSheets.Text = "Gestion fiches de frais";
            // 
            // dgv_expenses
            // 
            this.dgv_expenses.AllowUserToAddRows = false;
            this.dgv_expenses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_expenses.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdExpense,
            this.Description,
            this.Amount,
            this.Quantity,
            this.ExpenseType,
            this.State,
            this.CreationDate,
            this.Proof,
            this.Update});
            this.dgv_expenses.Location = new System.Drawing.Point(21, 318);
            this.dgv_expenses.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_expenses.Name = "dgv_expenses";
            this.dgv_expenses.Size = new System.Drawing.Size(845, 314);
            this.dgv_expenses.TabIndex = 5;
            this.dgv_expenses.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_expenseSheets_CellContentClick);
            // 
            // dgv_expenseSheet
            // 
            this.dgv_expenseSheet.AllowUserToAddRows = false;
            this.dgv_expenseSheet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_expenseSheet.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdExpenseSheet,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.Choose});
            this.dgv_expenseSheet.Location = new System.Drawing.Point(21, 109);
            this.dgv_expenseSheet.Margin = new System.Windows.Forms.Padding(4);
            this.dgv_expenseSheet.Name = "dgv_expenseSheet";
            this.dgv_expenseSheet.Size = new System.Drawing.Size(644, 160);
            this.dgv_expenseSheet.TabIndex = 33;
            this.dgv_expenseSheet.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // IdExpenseSheet
            // 
            this.IdExpenseSheet.HeaderText = "Id";
            this.IdExpenseSheet.Name = "IdExpenseSheet";
            this.IdExpenseSheet.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Reference";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Montant";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Etat";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Date de création";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Personne concernée";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // Choose
            // 
            this.Choose.HeaderText = "Afficher les frais";
            this.Choose.Name = "Choose";
            this.Choose.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Choose.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // btn_show
            // 
            this.btn_show.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_show.FlatAppearance.BorderSize = 0;
            this.btn_show.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_show.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_show.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_show.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_show.Location = new System.Drawing.Point(21, 79);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 23);
            this.btn_show.TabIndex = 46;
            this.btn_show.Text = "Afficher";
            this.btn_show.UseVisualStyleBackColor = false;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // IdExpense
            // 
            this.IdExpense.HeaderText = "Id";
            this.IdExpense.Name = "IdExpense";
            this.IdExpense.Visible = false;
            // 
            // Description
            // 
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Montant";
            this.Amount.Name = "Amount";
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantité";
            this.Quantity.Name = "Quantity";
            // 
            // ExpenseType
            // 
            this.ExpenseType.HeaderText = "Type de frais";
            this.ExpenseType.Name = "ExpenseType";
            // 
            // State
            // 
            this.State.HeaderText = "Etat";
            this.State.Name = "State";
            // 
            // CreationDate
            // 
            this.CreationDate.HeaderText = "Date de création";
            this.CreationDate.Name = "CreationDate";
            // 
            // Proof
            // 
            this.Proof.HeaderText = "Preuve";
            this.Proof.Name = "Proof";
            // 
            // Update
            // 
            this.Update.HeaderText = "Modifier";
            this.Update.Name = "Update";
            this.Update.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Update.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // btn_refresh
            // 
            this.btn_refresh.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_refresh.FlatAppearance.BorderSize = 0;
            this.btn_refresh.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_refresh.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_refresh.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refresh.Location = new System.Drawing.Point(791, 288);
            this.btn_refresh.Name = "btn_refresh";
            this.btn_refresh.Size = new System.Drawing.Size(75, 23);
            this.btn_refresh.TabIndex = 47;
            this.btn_refresh.Text = "Rafraîchir";
            this.btn_refresh.UseVisualStyleBackColor = false;
            this.btn_refresh.Click += new System.EventHandler(this.btn_refresh_Click);
            // 
            // frm_expenseSheets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1043, 675);
            this.Controls.Add(this.btn_refresh);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.dgv_expenseSheet);
            this.Controls.Add(this.dgv_expenses);
            this.Controls.Add(this.lbl_expenseSheets);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_expenseSheets";
            this.Text = "Gestion des fiches de frais";
            this.Load += new System.EventHandler(this.frm_expenseSheets_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_expenses)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_expenseSheet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_expenseSheets;
        private System.Windows.Forms.DataGridView dgv_expenses;
        private System.Windows.Forms.DataGridView dgv_expenseSheet;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdExpenseSheet;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewButtonColumn Choose;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdExpense;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ExpenseType;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn CreationDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Proof;
        private System.Windows.Forms.DataGridViewButtonColumn Update;
        private System.Windows.Forms.Button btn_refresh;
    }
}
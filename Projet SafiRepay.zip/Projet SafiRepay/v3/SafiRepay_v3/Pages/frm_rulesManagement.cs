﻿using SafiRepay.Pages;
using SafiRepay.RAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay
{
    public partial class frm_rulesManagement : Form
    {
        private frm_simulation activeSimulation = null;
        private frm_rulesManagementAdd activeAdd = null;
        private frm_ruleUpdate activeUpdate = null;

        public frm_rulesManagement()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        public void frm_rulesManagement_Load(object sender, EventArgs e)
        {
            btn_simulation.Hide();
            foreach (ExpensePackages ep in ExpensePackagesRAO.getAll())
            {
                var id = ep.id;
                var name = ep.name;
                var amount = ep.amount;
                var unit = " €";
                dgv_rulesManagement.Rows.Add(id, name, amount + unit);
            }
        }

        public void dgv_refresh()
        {
            dgv_rulesManagement.Rows.Clear();
            foreach (ExpensePackages ep in ExpensePackagesRAO.getAll())
            {
                var id = ep.id;
                var name = ep.name;
                var amount = ep.amount;
                var unit = " €";
                dgv_rulesManagement.Rows.Add(id, name, amount + unit);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Ajouter_Click(object sender, EventArgs e)
        {
            
        }

        private void btn_simulation_Click(object sender, EventArgs e)
        {
            frm_simulation frm_sim;
            if (null == activeSimulation)
            {
                frm_sim = new frm_simulation();
                frm_sim.Show();
                activeSimulation = frm_sim;
            }
            else
            {
                if (activeSimulation.isClosedSimulation == true)
                {
                    activeSimulation = null;
                    frm_sim = new frm_simulation();
                    frm_sim.Show();
                    activeSimulation = frm_sim;
                }
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            frm_rulesManagementAdd frm_add;
            if (null == activeAdd)
            {
                frm_add = new frm_rulesManagementAdd();
                frm_add.Show();
                activeAdd = frm_add;
            }
            else
            {
                if (activeAdd.isClosedAdd == true)
                {
                    activeAdd = null;
                    frm_add = new frm_rulesManagementAdd();
                    frm_add.Show();
                    activeAdd = frm_add;
                }
            }
        }

        private void btn_delete1_Click(object sender, EventArgs e)
        {

        }

        private void rAOBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void dgv_rulesManagement_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dgv_rulesManagement.Rows)
            {
                if (row.Cells[3].Selected == true)
                {
                    frm_ruleUpdate frm_ruleUpdate;
                    if (null == activeUpdate)
                    {
                        string id = row.Cells[0].Value.ToString();
                        string name = row.Cells[1].Value.ToString();
                        string amount = row.Cells[2].Value.ToString();
                        frm_ruleUpdate = new frm_ruleUpdate(name, amount, id);
                        frm_ruleUpdate.Show();
                        activeUpdate = frm_ruleUpdate;
                    }
                    else
                    {
                        if (activeUpdate.isClosedUpdate == true)
                        {
                            activeUpdate = null;
                            string id = row.Cells[0].Value.ToString();
                            string name = row.Cells[1].Value.ToString();
                            string amount = row.Cells[2].Value.ToString();
                            frm_ruleUpdate = new frm_ruleUpdate(name, amount, id);
                            frm_ruleUpdate.Show();
                            activeUpdate = frm_ruleUpdate;
                        }
                    }
                }
                if (row.Cells[4].Selected == true)
                {
                    var id = row.Cells[0].Value;
                    ExpensePackagesRAO.deleteOne(Convert.ToInt32(id));
                    dgv_rulesManagement.Rows.Remove(row);

                }
            }
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        { 
            this.dgv_refresh();
        }
    }
}

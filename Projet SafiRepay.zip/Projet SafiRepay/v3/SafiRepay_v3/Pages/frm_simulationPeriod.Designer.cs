﻿namespace SafiRepay
{
    partial class frm_simulationPeriod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtp_periodChoice = new System.Windows.Forms.DateTimePicker();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_validate = new System.Windows.Forms.Button();
            this.lbl_periodChoice = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dtp_periodChoice
            // 
            this.dtp_periodChoice.Location = new System.Drawing.Point(146, 33);
            this.dtp_periodChoice.Name = "dtp_periodChoice";
            this.dtp_periodChoice.Size = new System.Drawing.Size(200, 20);
            this.dtp_periodChoice.TabIndex = 40;
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_back.FlatAppearance.BorderSize = 0;
            this.btn_back.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_back.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(241, 73);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(89, 30);
            this.btn_back.TabIndex = 39;
            this.btn_back.Text = "Retour";
            this.btn_back.UseVisualStyleBackColor = false;
            // 
            // btn_validate
            // 
            this.btn_validate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_validate.FlatAppearance.BorderSize = 0;
            this.btn_validate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_validate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_validate.Location = new System.Drawing.Point(146, 73);
            this.btn_validate.Name = "btn_validate";
            this.btn_validate.Size = new System.Drawing.Size(89, 30);
            this.btn_validate.TabIndex = 38;
            this.btn_validate.Text = "Valider";
            this.btn_validate.UseVisualStyleBackColor = false;
            // 
            // lbl_periodChoice
            // 
            this.lbl_periodChoice.AutoSize = true;
            this.lbl_periodChoice.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_periodChoice.Location = new System.Drawing.Point(12, 33);
            this.lbl_periodChoice.Name = "lbl_periodChoice";
            this.lbl_periodChoice.Size = new System.Drawing.Size(127, 16);
            this.lbl_periodChoice.TabIndex = 37;
            this.lbl_periodChoice.Text = "Choisir une période :";
            // 
            // frm_simulationPeriod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(375, 129);
            this.Controls.Add(this.dtp_periodChoice);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_validate);
            this.Controls.Add(this.lbl_periodChoice);
            this.Name = "frm_simulationPeriod";
            this.Text = "Période de simulation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtp_periodChoice;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_validate;
        private System.Windows.Forms.Label lbl_periodChoice;
    }
}
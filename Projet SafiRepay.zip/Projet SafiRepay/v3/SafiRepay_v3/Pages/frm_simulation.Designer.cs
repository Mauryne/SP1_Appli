﻿namespace SafiRepay
{
    partial class frm_simulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint1 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint2 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint3 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint4 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 0D);
            this.lbl_simulation = new System.Windows.Forms.Label();
            this.lbl_rulesSimulation = new System.Windows.Forms.Label();
            this.btn_echap = new System.Windows.Forms.Button();
            this.btn_validate = new System.Windows.Forms.Button();
            this.btn_dateChoice = new System.Windows.Forms.Button();
            this.cht_rulesManagement = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.cht_rulesManagement)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_simulation
            // 
            this.lbl_simulation.AutoSize = true;
            this.lbl_simulation.Font = new System.Drawing.Font("Nachlieli CLM", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_simulation.Location = new System.Drawing.Point(12, 9);
            this.lbl_simulation.Name = "lbl_simulation";
            this.lbl_simulation.Size = new System.Drawing.Size(140, 30);
            this.lbl_simulation.TabIndex = 5;
            this.lbl_simulation.Text = "Simulation";
            // 
            // lbl_rulesSimulation
            // 
            this.lbl_rulesSimulation.AutoSize = true;
            this.lbl_rulesSimulation.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_rulesSimulation.Location = new System.Drawing.Point(14, 55);
            this.lbl_rulesSimulation.Name = "lbl_rulesSimulation";
            this.lbl_rulesSimulation.Size = new System.Drawing.Size(258, 18);
            this.lbl_rulesSimulation.TabIndex = 7;
            this.lbl_rulesSimulation.Text = "Simulation des règles sélectionnées";
            this.lbl_rulesSimulation.Click += new System.EventHandler(this.lbl_rulesSimulation_Click);
            // 
            // btn_echap
            // 
            this.btn_echap.FlatAppearance.BorderSize = 0;
            this.btn_echap.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_echap.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_echap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_echap.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_echap.Location = new System.Drawing.Point(404, 452);
            this.btn_echap.Name = "btn_echap";
            this.btn_echap.Size = new System.Drawing.Size(89, 23);
            this.btn_echap.TabIndex = 31;
            this.btn_echap.Text = "Annuler";
            this.btn_echap.UseVisualStyleBackColor = true;
            this.btn_echap.Click += new System.EventHandler(this.btn_echap_Click);
            // 
            // btn_validate
            // 
            this.btn_validate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_validate.FlatAppearance.BorderSize = 0;
            this.btn_validate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_validate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_validate.Location = new System.Drawing.Point(402, 396);
            this.btn_validate.Name = "btn_validate";
            this.btn_validate.Size = new System.Drawing.Size(89, 30);
            this.btn_validate.TabIndex = 32;
            this.btn_validate.Text = "Valider";
            this.btn_validate.UseVisualStyleBackColor = false;
            this.btn_validate.Click += new System.EventHandler(this.btn_validate_Click);
            // 
            // btn_dateChoice
            // 
            this.btn_dateChoice.FlatAppearance.BorderSize = 0;
            this.btn_dateChoice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_dateChoice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_dateChoice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_dateChoice.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dateChoice.Location = new System.Drawing.Point(354, 82);
            this.btn_dateChoice.Name = "btn_dateChoice";
            this.btn_dateChoice.Size = new System.Drawing.Size(137, 23);
            this.btn_dateChoice.TabIndex = 33;
            this.btn_dateChoice.Text = "Sélectionner une période";
            this.btn_dateChoice.UseVisualStyleBackColor = true;
            this.btn_dateChoice.Click += new System.EventHandler(this.btn_dateChoice_Click);
            // 
            // cht_rulesManagement
            // 
            this.cht_rulesManagement.BackColor = System.Drawing.SystemColors.AppWorkspace;
            chartArea1.BackColor = System.Drawing.Color.Transparent;
            chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.Center;
            chartArea1.BackHatchStyle = System.Windows.Forms.DataVisualization.Charting.ChartHatchStyle.BackwardDiagonal;
            chartArea1.Name = "ChartArea1";
            this.cht_rulesManagement.ChartAreas.Add(chartArea1);
            legend1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            legend1.Name = "Legend1";
            this.cht_rulesManagement.Legends.Add(legend1);
            this.cht_rulesManagement.Location = new System.Drawing.Point(19, 111);
            this.cht_rulesManagement.Name = "cht_rulesManagement";
            this.cht_rulesManagement.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Chocolate;
            series1.BackImageTransparentColor = System.Drawing.Color.Black;
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Fiches de frais";
            series1.Points.Add(dataPoint1);
            series1.Points.Add(dataPoint2);
            series1.Points.Add(dataPoint3);
            series1.Points.Add(dataPoint4);
            series1.ShadowColor = System.Drawing.Color.White;
            this.cht_rulesManagement.Series.Add(series1);
            this.cht_rulesManagement.Size = new System.Drawing.Size(474, 364);
            this.cht_rulesManagement.TabIndex = 34;
            this.cht_rulesManagement.Text = "chart1";
            this.cht_rulesManagement.Click += new System.EventHandler(this.cht_rulesManagement_Click);
            // 
            // frm_simulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(505, 487);
            this.Controls.Add(this.btn_dateChoice);
            this.Controls.Add(this.btn_validate);
            this.Controls.Add(this.btn_echap);
            this.Controls.Add(this.lbl_rulesSimulation);
            this.Controls.Add(this.lbl_simulation);
            this.Controls.Add(this.cht_rulesManagement);
            this.Name = "frm_simulation";
            this.Text = "Simulation";
            this.Load += new System.EventHandler(this.frm_simulation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cht_rulesManagement)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_simulation;
        private System.Windows.Forms.Label lbl_rulesSimulation;
        private System.Windows.Forms.Button btn_echap;
        private System.Windows.Forms.Button btn_validate;
        private System.Windows.Forms.Button btn_dateChoice;
        private System.Windows.Forms.DataVisualization.Charting.Chart cht_rulesManagement;
    }
}
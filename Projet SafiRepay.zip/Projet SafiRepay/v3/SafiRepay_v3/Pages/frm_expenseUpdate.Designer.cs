﻿namespace SafiRepay.Pages
{
    partial class frm_expenseUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_amount = new System.Windows.Forms.TextBox();
            this.lbl_amount = new System.Windows.Forms.Label();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_validate = new System.Windows.Forms.Button();
            this.lbl_state = new System.Windows.Forms.Label();
            this.lbl_proof = new System.Windows.Forms.Label();
            this.tbx_quantity = new System.Windows.Forms.TextBox();
            this.lbl_quantity = new System.Windows.Forms.Label();
            this.rbtn_yes = new System.Windows.Forms.RadioButton();
            this.rbtn_no = new System.Windows.Forms.RadioButton();
            this.lbx_state = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // tbx_amount
            // 
            this.tbx_amount.Location = new System.Drawing.Point(164, 86);
            this.tbx_amount.Name = "tbx_amount";
            this.tbx_amount.Size = new System.Drawing.Size(100, 20);
            this.tbx_amount.TabIndex = 52;
            // 
            // lbl_amount
            // 
            this.lbl_amount.AutoSize = true;
            this.lbl_amount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_amount.Location = new System.Drawing.Point(36, 90);
            this.lbl_amount.Name = "lbl_amount";
            this.lbl_amount.Size = new System.Drawing.Size(63, 16);
            this.lbl_amount.TabIndex = 51;
            this.lbl_amount.Text = "Montant :";
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_back.FlatAppearance.BorderSize = 0;
            this.btn_back.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_back.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_back.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.Location = new System.Drawing.Point(211, 228);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(89, 30);
            this.btn_back.TabIndex = 49;
            this.btn_back.Text = "Retour";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click);
            // 
            // btn_validate
            // 
            this.btn_validate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_validate.FlatAppearance.BorderSize = 0;
            this.btn_validate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_validate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_validate.Location = new System.Drawing.Point(116, 228);
            this.btn_validate.Name = "btn_validate";
            this.btn_validate.Size = new System.Drawing.Size(89, 30);
            this.btn_validate.TabIndex = 48;
            this.btn_validate.Text = "Valider";
            this.btn_validate.UseVisualStyleBackColor = false;
            this.btn_validate.Click += new System.EventHandler(this.btn_validate_Click);
            // 
            // lbl_state
            // 
            this.lbl_state.AutoSize = true;
            this.lbl_state.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_state.Location = new System.Drawing.Point(36, 53);
            this.lbl_state.Name = "lbl_state";
            this.lbl_state.Size = new System.Drawing.Size(40, 16);
            this.lbl_state.TabIndex = 47;
            this.lbl_state.Text = "Etat :";
            // 
            // lbl_proof
            // 
            this.lbl_proof.AutoSize = true;
            this.lbl_proof.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proof.Location = new System.Drawing.Point(36, 164);
            this.lbl_proof.Name = "lbl_proof";
            this.lbl_proof.Size = new System.Drawing.Size(58, 16);
            this.lbl_proof.TabIndex = 55;
            this.lbl_proof.Text = "Preuve ?";
            // 
            // tbx_quantity
            // 
            this.tbx_quantity.Location = new System.Drawing.Point(164, 127);
            this.tbx_quantity.Name = "tbx_quantity";
            this.tbx_quantity.Size = new System.Drawing.Size(100, 20);
            this.tbx_quantity.TabIndex = 54;
            // 
            // lbl_quantity
            // 
            this.lbl_quantity.AutoSize = true;
            this.lbl_quantity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_quantity.Location = new System.Drawing.Point(36, 127);
            this.lbl_quantity.Name = "lbl_quantity";
            this.lbl_quantity.Size = new System.Drawing.Size(65, 16);
            this.lbl_quantity.TabIndex = 53;
            this.lbl_quantity.Text = "Quantité :";
            // 
            // rbtn_yes
            // 
            this.rbtn_yes.AutoSize = true;
            this.rbtn_yes.Location = new System.Drawing.Point(164, 163);
            this.rbtn_yes.Name = "rbtn_yes";
            this.rbtn_yes.Size = new System.Drawing.Size(41, 17);
            this.rbtn_yes.TabIndex = 57;
            this.rbtn_yes.TabStop = true;
            this.rbtn_yes.Text = "Oui";
            this.rbtn_yes.UseVisualStyleBackColor = true;
            // 
            // rbtn_no
            // 
            this.rbtn_no.AutoSize = true;
            this.rbtn_no.Location = new System.Drawing.Point(219, 163);
            this.rbtn_no.Name = "rbtn_no";
            this.rbtn_no.Size = new System.Drawing.Size(45, 17);
            this.rbtn_no.TabIndex = 58;
            this.rbtn_no.TabStop = true;
            this.rbtn_no.Text = "Non";
            this.rbtn_no.UseVisualStyleBackColor = true;
            // 
            // lbx_state
            // 
            this.lbx_state.FormattingEnabled = true;
            this.lbx_state.Items.AddRange(new object[] {
            "En attente de validation",
            "En attente de preuve",
            "Validé",
            "Refusé pour manque de preuve",
            "Refusé pour montant trop élevé"});
            this.lbx_state.Location = new System.Drawing.Point(127, 13);
            this.lbx_state.Name = "lbx_state";
            this.lbx_state.Size = new System.Drawing.Size(173, 56);
            this.lbx_state.TabIndex = 59;
            // 
            // frm_expenseUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(312, 273);
            this.Controls.Add(this.lbx_state);
            this.Controls.Add(this.rbtn_no);
            this.Controls.Add(this.rbtn_yes);
            this.Controls.Add(this.lbl_proof);
            this.Controls.Add(this.tbx_quantity);
            this.Controls.Add(this.lbl_quantity);
            this.Controls.Add(this.tbx_amount);
            this.Controls.Add(this.lbl_amount);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_validate);
            this.Controls.Add(this.lbl_state);
            this.Name = "frm_expenseUpdate";
            this.Text = "frm_expenseUpdate";
            this.Load += new System.EventHandler(this.frm_expenseUpdate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_amount;
        private System.Windows.Forms.Label lbl_amount;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_validate;
        private System.Windows.Forms.Label lbl_state;
        private System.Windows.Forms.Label lbl_proof;
        private System.Windows.Forms.TextBox tbx_quantity;
        private System.Windows.Forms.Label lbl_quantity;
        private System.Windows.Forms.RadioButton rbtn_yes;
        private System.Windows.Forms.RadioButton rbtn_no;
        private System.Windows.Forms.ListBox lbx_state;
    }
}
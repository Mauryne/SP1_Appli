﻿namespace SafiRepay.Pages
{
    partial class frm_rulesManagementAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbx_ruleAmount = new System.Windows.Forms.TextBox();
            this.tbx_ruleName = new System.Windows.Forms.TextBox();
            this.btn_validate = new System.Windows.Forms.Button();
            this.btn_echap = new System.Windows.Forms.Button();
            this.lbl_ruleAmount = new System.Windows.Forms.Label();
            this.lbl_ruleAddTitle = new System.Windows.Forms.Label();
            this.lbl_ruleName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tbx_ruleAmount
            // 
            this.tbx_ruleAmount.Location = new System.Drawing.Point(275, 137);
            this.tbx_ruleAmount.Name = "tbx_ruleAmount";
            this.tbx_ruleAmount.Size = new System.Drawing.Size(201, 20);
            this.tbx_ruleAmount.TabIndex = 13;
            // 
            // tbx_ruleName
            // 
            this.tbx_ruleName.Location = new System.Drawing.Point(275, 93);
            this.tbx_ruleName.Name = "tbx_ruleName";
            this.tbx_ruleName.Size = new System.Drawing.Size(201, 20);
            this.tbx_ruleName.TabIndex = 12;
            // 
            // btn_validate
            // 
            this.btn_validate.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_validate.FlatAppearance.BorderSize = 0;
            this.btn_validate.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_validate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_validate.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_validate.Location = new System.Drawing.Point(306, 355);
            this.btn_validate.Name = "btn_validate";
            this.btn_validate.Size = new System.Drawing.Size(75, 23);
            this.btn_validate.TabIndex = 11;
            this.btn_validate.Text = "Valider";
            this.btn_validate.UseVisualStyleBackColor = false;
            this.btn_validate.Click += new System.EventHandler(this.btn_validate_Click);
            // 
            // btn_echap
            // 
            this.btn_echap.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btn_echap.FlatAppearance.BorderSize = 0;
            this.btn_echap.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.btn_echap.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btn_echap.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_echap.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_echap.Location = new System.Drawing.Point(387, 355);
            this.btn_echap.Name = "btn_echap";
            this.btn_echap.Size = new System.Drawing.Size(75, 23);
            this.btn_echap.TabIndex = 10;
            this.btn_echap.Text = "Annuler";
            this.btn_echap.UseVisualStyleBackColor = false;
            this.btn_echap.Click += new System.EventHandler(this.btn_echap_Click);
            // 
            // lbl_ruleAmount
            // 
            this.lbl_ruleAmount.AutoSize = true;
            this.lbl_ruleAmount.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ruleAmount.Location = new System.Drawing.Point(47, 137);
            this.lbl_ruleAmount.Name = "lbl_ruleAmount";
            this.lbl_ruleAmount.Size = new System.Drawing.Size(191, 16);
            this.lbl_ruleAmount.TabIndex = 9;
            this.lbl_ruleAmount.Text = "Montant de la règle de gestion :";
            // 
            // lbl_ruleAddTitle
            // 
            this.lbl_ruleAddTitle.AutoSize = true;
            this.lbl_ruleAddTitle.Font = new System.Drawing.Font("Nachlieli CLM", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.lbl_ruleAddTitle.Location = new System.Drawing.Point(12, 9);
            this.lbl_ruleAddTitle.Name = "lbl_ruleAddTitle";
            this.lbl_ruleAddTitle.Size = new System.Drawing.Size(347, 30);
            this.lbl_ruleAddTitle.TabIndex = 8;
            this.lbl_ruleAddTitle.Text = "Ajout d\'une règle de gestion";
            // 
            // lbl_ruleName
            // 
            this.lbl_ruleName.AutoSize = true;
            this.lbl_ruleName.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ruleName.Location = new System.Drawing.Point(47, 93);
            this.lbl_ruleName.Name = "lbl_ruleName";
            this.lbl_ruleName.Size = new System.Drawing.Size(182, 16);
            this.lbl_ruleName.TabIndex = 7;
            this.lbl_ruleName.Text = "Intitulé de la règle de gestion :";
            // 
            // frm_rulesManagementAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(496, 450);
            this.Controls.Add(this.tbx_ruleAmount);
            this.Controls.Add(this.tbx_ruleName);
            this.Controls.Add(this.btn_validate);
            this.Controls.Add(this.btn_echap);
            this.Controls.Add(this.lbl_ruleAmount);
            this.Controls.Add(this.lbl_ruleAddTitle);
            this.Controls.Add(this.lbl_ruleName);
            this.Name = "frm_rulesManagementAdd";
            this.Text = "Ajout d\'une règle de gestion";
            this.Load += new System.EventHandler(this.frm_rulesManagementAdd_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbx_ruleAmount;
        private System.Windows.Forms.TextBox tbx_ruleName;
        private System.Windows.Forms.Button btn_validate;
        private System.Windows.Forms.Button btn_echap;
        private System.Windows.Forms.Label lbl_ruleAmount;
        private System.Windows.Forms.Label lbl_ruleAddTitle;
        private System.Windows.Forms.Label lbl_ruleName;
    }
}
﻿using SafiRepay.Pages;
using SafiRepay.RAO;
using SafiRepay.RAO.ExpenseInPackages;
using SafiRepay.RAO.ExpenseOutPackages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using System.Windows.Forms;

namespace SafiRepay
{
    public partial class frm_expenseSheets : Form
    {
        private frm_expenseUpdate activeUpdate = null;
        public frm_expenseSheets()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void frm_expenseSheets_Load(object sender, EventArgs e)
        {

        }

        private void btn_actualiser_Click(object sender, EventArgs e)
        {

        }
        private void dgv_expenses_show()
        {
            dgv_expenses.Rows.Clear();
            foreach (DataGridViewRow row in dgv_expenseSheet.Rows)
            {
                if (row.Cells[6].Selected == true)
                {
                    string idExpenseSheet = row.Cells[0].Value.ToString();
                    foreach (Expenses expenseOutPackages in ExpensesRAO.getExpenseOutPackagesByExpenseSheet(idExpenseSheet))
                    {
                        List<ExpenseOutPackages> expensesOut = ExpenseOutPackagesRAO.getAll();

                        foreach (ExpenseOutPackages expenseOut in expensesOut)
                        {
                            if (expenseOut.expense_id == expenseOutPackages.id)
                            {
                                String stateName = "";
                                if (expenseOutPackages.expense_state.name == "waiting_for_validation")
                                {
                                    stateName = "En attente de validation";
                                }
                                else if (expenseOutPackages.expense_state.name == "waiting_for_proof")
                                {
                                    stateName = "En attente de preuve";
                                }
                                else if (expenseOutPackages.expense_state.name == "validated")
                                {
                                    stateName = "Validé";
                                }
                                else if (expenseOutPackages.expense_state.name == "waiting_for_missing_proof")
                                {
                                    stateName = "Refusé pour manque de preuve";
                                }
                                else if (expenseOutPackages.expense_state.name == "waiting_for_amount_too_high")
                                {
                                    stateName = "Refusé pour montant trop élevé";
                                }

                                var id = expenseOut.id;
                                var description = expenseOut.description;
                                var amount = expenseOut.amount + " €";
                                var quantity = expenseOutPackages.quantity;
                                var expenseType = "Non forfaitaire";
                                var jour = expenseOutPackages.created_at.Substring(3, 3);
                                var mois = expenseOutPackages.created_at.Substring(0, 2);
                                var année = expenseOutPackages.created_at.Substring(6, 4);
                                var date = jour + mois + "/" + année;
                                var proof = "Non";
                                if (expenseOut.expense_proof_id != null)
                                {
                                    proof = "Oui";
                                }
                                dgv_expenses.Rows.Add(id, description, amount, quantity, expenseType, stateName, date, proof);
                            }
                        }
                    }
                }

                if (row.Cells[6].Selected == true)
                {
                    string idExpenseSheet = row.Cells[0].Value.ToString();
                    foreach (Expenses expenseInPackages in ExpensesRAO.getExpenseInPackagesByExpenseSheet(idExpenseSheet))
                    {
                        List<ExpenseInPackages> expensesIn = ExpenseInPackagesRAO.getAll();

                        foreach (ExpenseInPackages expenseIn in expensesIn)
                        {
                            if (expenseIn.expense_id == expenseInPackages.id)
                            {
                                String stateName = "";
                                if (expenseInPackages.expense_state.name == "waiting_for_validation")
                                {
                                    stateName = "En attente de validation";
                                }
                                else if (expenseInPackages.expense_state.name == "waiting_for_proof")
                                {
                                    stateName = "En attente de preuve";
                                }
                                else if (expenseInPackages.expense_state.name == "validated")
                                {
                                    stateName = "Validé";
                                }
                                else if (expenseInPackages.expense_state.name == "waiting_for_missing_proof")
                                {
                                    stateName = "Refusé pour manque de preuve";
                                }
                                else if (expenseInPackages.expense_state.name == "waiting_for_amount_too_high")
                                {
                                    stateName = "Refusé pour montant trop élevé";
                                }

                                var id = expenseIn.id;
                                var description = expenseIn.expense_package.name;
                                var amount = expenseIn.expense_package.amount + " €";
                                var quantity = expenseInPackages.quantity;
                                var expenseType = "Forfaitaire";
                                var jour = expenseInPackages.created_at.Substring(3, 3);
                                var mois = expenseInPackages.created_at.Substring(0, 2);
                                var année = expenseInPackages.created_at.Substring(6, 4);
                                var date = jour + mois + "/" + année;
                                var proof = "Non";
                                dgv_expenses.Rows.Add(id, description, amount, quantity, expenseType, stateName, date, proof);
                            }
                        }
                    }

                }
            }
        }

        private void dgv_expenseSheets_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            foreach (DataGridViewRow row in dgv_expenses.Rows)
            {
                if (row.Cells[8].Selected == true)
                {
                    frm_expenseUpdate frm_expenseUpdate;
                    if (null == activeUpdate)
                    {
                        string id = row.Cells[0].Value.ToString();
                        string state = row.Cells[5].Value.ToString();
                        string amount = row.Cells[2].Value.ToString();
                        string quantity = row.Cells[3].Value.ToString();
                        string proof = row.Cells[7].Value.ToString();
                        frm_expenseUpdate = new frm_expenseUpdate(id, state, amount, quantity, proof);
                        frm_expenseUpdate.Show();
                        activeUpdate = frm_expenseUpdate;
                    }
                    else
                    {
                        if (activeUpdate.isClosedUpdate == true)
                        {
                            activeUpdate = null;
                            string id = row.Cells[0].Value.ToString();
                            string state = row.Cells[5].Value.ToString();
                            string amount = row.Cells[2].Value.ToString();
                            string quantity = row.Cells[3].Value.ToString();
                            string proof = row.Cells[7].Value.ToString();
                            frm_expenseUpdate = new frm_expenseUpdate(id, state, amount, quantity, proof);
                            frm_expenseUpdate.Show();
                            activeUpdate = frm_expenseUpdate;
                        }
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dgv_expenses_show();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dgv_expenseSheet.Rows.Clear();
            foreach (ExpenseSheets es in ExpenseSheetsRAO.getAllUntreated())
            {
                String sheetName = "Créé";
                String lastName = es.user.lastname.ToUpper();
                var id = es.id;
                var reference = es.reference;
                var amount = es.calculated_amount + " €";
                var state = sheetName;
                var jour = es.created_at.Substring(3, 3);
                var mois = es.created_at.Substring(0, 2);
                var année = es.created_at.Substring(6, 4);
                var date = jour + mois + "/" + année;
                var user = lastName + " " + es.user.firstname;
                dgv_expenseSheet.Rows.Add(id, reference, amount, state, date, user);
            }

            foreach (ExpenseSheets es in ExpenseSheetsRAO.getAllInWaiting())
            {
                String sheetName = "En attente de preuve";
                String lastName = es.user.lastname.ToUpper();
                var id = es.id;
                var reference = es.reference;
                var amount = es.calculated_amount + " €";
                var state = sheetName;
                var jour = es.created_at.Substring(3, 3);
                var mois = es.created_at.Substring(0, 2);
                var année = es.created_at.Substring(6, 4);
                var date = jour + mois + "/" + année;
                var user = lastName + " " + es.user.firstname;
                dgv_expenseSheet.Rows.Add(id, reference, amount, state, date, user);
            }
        }

        private void btn_refresh_Click(object sender, EventArgs e)
        {
            dgv_expenses_show();
        }

    }
}

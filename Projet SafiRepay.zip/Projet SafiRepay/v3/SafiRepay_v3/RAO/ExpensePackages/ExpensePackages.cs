﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpensePackages
    {
        public Int64 id { get; set; }
        public String name { get; set; }
        public Decimal amount { get; set; }
        public String created_at { get; set; }
        public String updated_at { get; set; }
    }
}

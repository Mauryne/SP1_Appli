﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpensePackagesRAO
    {
        static public List<ExpensePackages> getAll()
        {
            return JsonConvert.DeserializeObject<List<ExpensePackages>>(RAO.get("expense-packages/all"));
        }

        static public ExpensePackages getById(Int64 id)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-packages/" + id.ToString() + "/one"));
            return JsonConvert.DeserializeObject<ExpensePackages>(jsonParse.ToString());
        }

        static public void create(string name, string amount)
        {
            RAO.create("expense-packages/create", name, amount);
        }

        static public void updateOne(string id, string name, string amount)
        {
            RAO.update("expense-packages/", id, name, amount);
        }

        static public void deleteOne(Int64 id)
        {
            RAO.delete("expense-packages/delete", id);
            
        }
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO.ExpenseInPackages
{
    class ExpenseInPackagesRAO
    {
        static public List<ExpenseInPackages> getAll()
        {
            return JsonConvert.DeserializeObject<List<ExpenseInPackages>>(RAO.get("expenses-in-packages/all"));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO.ExpenseInPackages
{
    class ExpenseInPackages
    {
        public int id { get; set; }
        public int expense_package_type_id { get; set; }
        public int expense_id { get; set; }

        public Expenses expense { get; set; }

        public ExpensePackages expense_package { get; set; }
    }
}

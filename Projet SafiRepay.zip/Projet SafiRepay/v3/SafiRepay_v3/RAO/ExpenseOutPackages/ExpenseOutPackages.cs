﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO.ExpenseOutPackages
{
    class ExpenseOutPackages
    {
        public int id { get; set; }
        public String description { get; set; }
        public Decimal amount { get; set; }
        public int expense_proof_id { get; set; }
        public int expense_id { get; set; }

        public Expenses expense { get; set; }
    }
}

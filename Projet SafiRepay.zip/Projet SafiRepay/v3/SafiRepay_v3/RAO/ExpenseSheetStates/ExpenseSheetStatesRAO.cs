﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpenseSheetstatesRAO
    {
        static public Expenses getById(Int64 id)
        {
            // Transforme la chaine de caractère du RAO en objet JSON = parser
            JObject jsonParse = JObject.Parse(RAO.get("expenses-sheet-state" + id.ToString() + "/one"));
            //Debug.WriteLine(jsonParse.ToString());
            // Retourne un objet de la classe User à partir de la chaine de caractère de l'objet JSON parsé avec clef "data"
            return JsonConvert.DeserializeObject<Expenses>(jsonParse.ToString());
        }
    }
}

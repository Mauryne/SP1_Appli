﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using RestSharp;

namespace SafiRepay.RAO
{
    class RAO
    {
        public static string get(string url, string apikey = null)
        {
            RestClient client = new RestClient();
            client.BaseUrl = new Uri(Properties.Settings.Default.API_URL + "/");

            RestRequest request = new RestRequest();
            request.Resource = url;
            IRestResponse response = client.Execute(request);

            return response.Content;
        }

        public static void delete(string url, Int64 id, string apikey = null)
        {
            var clientCpu = new RestClient(Properties.Settings.Default.API_URL + "/" + url);
            var del = new RestRequest($"/{id}", Method.DELETE);

            del.AddHeader("Content-Type", "application/x-www-form-urlencoded");
            del.AddHeader("Content-Length", "0");

            clientCpu.Delete(del);
        }

        public static void update(string url, string id, string name, string amount, string apikey = null)
        {
            var clientCpu = new RestClient(Properties.Settings.Default.API_URL + "/" + url);
            var update = new RestRequest($"/{id}", Method.PUT);

            update.AddHeader("Content-Type", "application/json");
            update.AddJsonBody(new { name, amount });

            clientCpu.Execute(update);
        }

        public static void create(string url, string name, string amount, string apikey = null)
        {
            var clientCpu = new RestClient(Properties.Settings.Default.API_URL + "/" + url);
            var creation = new RestRequest(Method.POST);

            creation.AddHeader("Content-Type", "application/json");
            creation.AddJsonBody(new { name, amount });

            clientCpu.Execute(creation);
        }
    }
}

﻿using System;

namespace SafiRepay.RAO
{
    public class ExpenseStates
    {
        public int id { get; set; }
        public String name { get; set; }
    }
}
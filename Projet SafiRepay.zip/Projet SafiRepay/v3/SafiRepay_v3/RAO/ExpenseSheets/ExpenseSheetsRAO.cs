﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpenseSheetsRAO
    {
        static public ExpenseSheets getById(Int64 id)
        {
            // Transforme la chaine de caractère du RAO en objet JSON = parser
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/" + id.ToString() + "/one"));
            //Debug.WriteLine(jsonParse.ToString());
            // Retourne un objet de la classe User à partir de la chaine de caractère de l'objet JSON parsé avec clef "data"
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public List<ExpenseSheets> getAllInWaiting(IDictionary<string, string> paramObject = null)
        {
            String jsonContentExpenseSheets = RAO.get("expense-sheets/waiting");
            
            JArray objectUser = JArray.Parse(jsonContentExpenseSheets);
            

            List<JToken> results = objectUser.Children().ToList();

            List<ExpenseSheets> expenseSheets = new List<ExpenseSheets>();
            foreach (JToken result in results)
            {
                ExpenseSheets searchResult = result.ToObject<ExpenseSheets>();
                expenseSheets.Add(searchResult);
                //Debug.WriteLine(expenseSheets);
            }
            return expenseSheets;
        }

        static public List<ExpenseSheets> getAllUntreated()
        {
            String jsonContentExpenseSheets = RAO.get("expense-sheets/untreated/all");
            JArray objectUser = JArray.Parse(jsonContentExpenseSheets);

            List<JToken> results = objectUser.Children().ToList();

            List<ExpenseSheets> expenseSheets = new List<ExpenseSheets>();
            foreach (JToken result in results)
            {
                ExpenseSheets searchResult = result.ToObject<ExpenseSheets>();
                expenseSheets.Add(searchResult);
            }
            return expenseSheets;

        }

        static public ExpenseSheets updateById(Int64 id)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/" + id.ToString() + "/update"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public List<ExpenseSheets> getAllByDate(string date)
        {
            return JsonConvert.DeserializeObject<List<ExpenseSheets>>(RAO.get("expense-sheets/" + date + "/date"));
        }

        //TODO
        static public ExpenseSheets updateAllUntreated()
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/untreated/update"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public ExpenseSheets getAllUntreatedByDate(string date)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/untreated/" + date));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public ExpenseSheets updateAllByDate(string date)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/" + date + "/update"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        //TODO
        static public ExpenseSheets updateAllUntreatedByDate(string date)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/untreated/" + date + "/update"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public ExpenseSheets getAllValidatedByDate(string date)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/validated/" + date + "/all"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public ExpenseSheets getAllByMedicalVisitor(Int64 id)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/users/" + id.ToString() + "/historical"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }

        static public ExpenseSheets getAllByMedicalVisitorByDate(Int64 id, string date)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expense-sheets/users/" + id.ToString() + date + "/historical"));
            return JsonConvert.DeserializeObject<ExpenseSheets>(jsonParse.ToString());
        }
    }
}
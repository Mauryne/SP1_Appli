﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpenseSheets
    {
        public int id { get; set; }
        public int user_id { get; set; }
        public String reference { get; set; }
        public Decimal calculated_amount { get; set; }
        public int sheet_state_id { get; set; }
        public String created_at { get; set; }
        public String modification_date { get; set; }

        public Users user { get; set; }

        public ExpenseSheetStates expense_sheet_state { get; set; }
    }
}

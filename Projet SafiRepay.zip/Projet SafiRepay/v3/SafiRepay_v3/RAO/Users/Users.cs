﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    public class Users
    {
        public int id { get; set; }
        public String code { get; set; }
        public int leader_id { get; set; }
        public int district_id { get; set; }
        public int role_id { get; set; }
        public String postal_code { get; set; }
        public String firstname { get; set; }
        public String lastname { get; set; }
        public String login { get; set; }
        public String password { get; set; }
        public String address { get; set; }
        public String city { get; set; }
        public String phone { get; set; }
        public String release_date { get; set; }
        public String entry_date { get; set; }
        public String token { get; set; }
        public int timespan { get; set; }
        public String mail_address { get; set; }
    }
}

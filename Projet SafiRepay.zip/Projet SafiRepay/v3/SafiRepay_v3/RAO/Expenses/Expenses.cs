﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class Expenses
    {
        public int id { get; set; }
        public int expense_sheet_id { get; set; }
        public int expense_state_id { get; set; }
        public int quantity { get; set; }
        public String created_at { get; set; }
        public ExpenseStates expense_state { get; set; }
    }
}

﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SafiRepay.RAO
{
    class ExpensesRAO
    {
        static public Expenses getById(Int64 id)
        {
            // Transforme la chaine de caractère du RAO en objet JSON = parser
            JObject jsonParse = JObject.Parse(RAO.get("expenses" + id.ToString() + "/one"));
            //Debug.WriteLine(jsonParse.ToString());
            // Retourne un objet de la classe User à partir de la chaine de caractère de l'objet JSON parsé avec clef "data"
            return JsonConvert.DeserializeObject<Expenses>(jsonParse.ToString());
        }

        static public void updateOne(string id, string quantity, string amount, string expense_state_id)
        {
            RAO.update("expenses/", id, quantity, amount, expense_state_id);
        }

        static public Expenses getByState(Int64 id)
        {
            JObject jsonParse = JObject.Parse(RAO.get("expenses/" + id.ToString() + "/state"));
            return JsonConvert.DeserializeObject<Expenses>(jsonParse.ToString());
        }

        
        static public List<Expenses> getExpenseInPackagesByExpenseSheet(string id, IDictionary<string, string> paramObject = null)
        {
            String jsonContentExpenses = RAO.get("expenses/expense-sheet/expense-in/" + id.ToString() + "/all");

            JArray objectUser = JArray.Parse(jsonContentExpenses);

            List<JToken> results = objectUser.Children().ToList();

            List<Expenses> expenses = new List<Expenses>();
            foreach (JToken result in results)
            {
                Expenses searchResult = result.ToObject<Expenses>();
                expenses.Add(searchResult);
                //Debug.WriteLine(expenseSheets);
            }
            return expenses;
        }

        static public List<Expenses> getExpenseOutPackagesByExpenseSheet(string id, IDictionary<string, string> paramObject = null)
        {
            String jsonContentExpenses = RAO.get("expenses/expense-sheet/expense-out/" + id.ToString() + "/all");

            JArray objectUser = JArray.Parse(jsonContentExpenses);


            List<JToken> results = objectUser.Children().ToList();

            List<Expenses> expenses = new List<Expenses>();
            foreach (JToken result in results)
            {
                Expenses searchResult = result.ToObject<Expenses>();
                expenses.Add(searchResult);
                //Debug.WriteLine(expenseSheets);
            }
            return expenses;
        }

    }
}

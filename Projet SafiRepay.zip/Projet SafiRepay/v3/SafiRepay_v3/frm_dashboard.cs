﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SafiRepay
{
    public partial class frm_dashboard : Form
    {
        private Form activeWindow = null;

        public frm_dashboard()
        {
            InitializeComponent();
        }

        private void pnl_window_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frm_dashboard_Load(object sender, EventArgs e)
        {

        }

        private void btn_deconnection_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_expenseSheets_Click(object sender, EventArgs e)
        {
            if (this.activeWindow != null)
            {
                this.activeWindow.Close();
            }

            frm_expenseSheets newWin = new frm_expenseSheets();
            this.activeWindow = newWin;
            newWin.TopLevel = false;
            newWin.FormBorderStyle = FormBorderStyle.None;

            pnl_window.Controls.Add(newWin);
            pnl_window.Tag = newWin;

            newWin.BringToFront();
            newWin.Show();
        }

        private void pnl_menu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_rulesManagement_Click(object sender, EventArgs e)
        {
            if (this.activeWindow != null)
            {
                this.activeWindow.Close();
            }

            frm_rulesManagement newWin = new frm_rulesManagement();
            this.activeWindow = newWin;
            newWin.TopLevel = false;
            newWin.FormBorderStyle = FormBorderStyle.None;

            pnl_window.Controls.Add(newWin);
            pnl_window.Tag = newWin;

            newWin.BringToFront();
            newWin.Show();
        }
    }
}
